#!/bin/sh

./resort
